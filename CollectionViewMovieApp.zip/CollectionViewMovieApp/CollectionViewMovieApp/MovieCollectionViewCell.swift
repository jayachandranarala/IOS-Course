//
//  MovieCollectionViewCell.swift
//  CollectionViewMovieApp
//
//  Created by Narala,Jayachandra on 4/20/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    //Assign
    
    func assignMovies(movie: Movie){
        imageViewOutlet.image = movie.image
    }

    
}
