//
//  ViewController.swift
//  StudentApp
//
//  Created by Narala,Jayachandra on 4/4/23.
//

import UIKit

class loginViewController: UIViewController {

    
    
    @IBOutlet weak var sidInputOutlet: UITextField!
    
    // create a global variable for holding a student
    
    var studentFound = student()
    
    // to check wheather user is student/guest
    // initially isStudent is false that means user is a guest
    var isStudent = false
    
    //Array of type student, we 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    
    
    @IBAction func studentDetailsButton(_ sender: UIButton) {
    }
    
    
}

