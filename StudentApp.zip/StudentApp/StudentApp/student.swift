//
//  student.swift
//  StudentApp
//
//  Created by Narala,Jayachandra on 4/4/23.
//

import Foundation


struct student{
    
}
