//
//  studentViewViewController.swift
//  StudentApp
//
//  Created by Narala,Jayachandra on 4/4/23.
//

import UIKit

class studentViewViewController: UIViewController {

    
    
    @IBOutlet weak var studentNameOutlet: UILabel!
    
    
    
    @IBOutlet weak var studentSidOutlet: UILabel!
    
    
    
    @IBOutlet weak var studentEmailOutlet: UILabel!
    
    
    
    @IBOutlet weak var studentDOBOutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    
    
    @IBAction func viewCoursesButton(_ sender: UIButton) {
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
