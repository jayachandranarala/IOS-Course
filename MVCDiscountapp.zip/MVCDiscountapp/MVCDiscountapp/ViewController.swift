//
//  ViewController.swift
//  MVCDiscountapp
//
//  Created by Narala,Jayachandra on 3/30/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var amountOutlet: UITextField!
    

    @IBOutlet weak var discountrateOutlet: UITextField!
    
    var priceAfterDiscount = 0.0
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    
    @IBAction func calculateprice(_ sender: Any) {
        //Read the text and convert it to double
        var amount = Double(amountOutlet.text!)
        print(amount!)
        
        var discountRate = Double(discountrateOutlet.text!)
        print(discountRate)
        
        
        priceAfterDiscount = amount! - (amount!*discountRate!/100)
        print(priceAfterDiscount)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Creat a transistion
        var transition = segue.identifier
        // create destination
        if(transition == "ResultSegue"){
            // reach destination
            
            var destination = segue.destination as! ResultViewController
            
            destination.destinationAmount = amountOutlet.text!
            destination.destinationDiscountRate = discountrateOutlet.text!
            destination.destinationResult = String(priceAfterDiscount)
            
            
            
            
            
        }
    }
    
    
}

