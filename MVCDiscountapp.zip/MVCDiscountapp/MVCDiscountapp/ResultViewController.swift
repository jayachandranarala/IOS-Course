//
//  ResultViewController.swift
//  MVCDiscountapp
//
//  Created by Narala,Jayachandra on 3/30/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    
    @IBOutlet weak var displayamountOutlet: UILabel!
    
    
    
    @IBOutlet weak var displayDiscRateOutlet: UILabel!
    
    
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    // Place to store the values
    
    var destinationAmount = ""
    var destinationDiscountRate = ""
    var destinationResult = ""
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        displayamountOutlet.text = displayamountOutlet.text! + destinationAmount;
        displayDiscRateOutlet.text = displayDiscRateOutlet.text! + destinationDiscountRate
        resultOutlet.text = resultOutlet.text! + destinationResult
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
