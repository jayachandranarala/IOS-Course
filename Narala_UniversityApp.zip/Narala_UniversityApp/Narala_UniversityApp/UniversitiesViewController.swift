//
//  ViewController.swift
//  Narala_UniversityApp
//
//  Created by Narala,Jayachandra on 4/19/23.
//

import UIKit

class UniversitiesViewController: UIViewController {

    
    
    @IBOutlet weak var universitiesTableView: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

