//
//  UniversityInfoViewController.swift
//  Narala_UniversityApp
//
//  Created by Narala,Jayachandra on 4/19/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {

    
    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    
    
    var imageview = ""
    var textview = ""
    var tit = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = tit
                universityImageViewOutlet.image = UIImage(named: imageview)
        print(textview)
        
        universityImageViewOutlet.frame.origin.x = view.frame.maxX

        
        var width = universityImageViewOutlet.frame.width
        var x = 87.0
        
        var height = universityImageViewOutlet.frame.height
        var y = 172.0
        
        
        var lFrame = CGRect(x : x, y:y, width: width, height: height)
        
        UIView.animate(withDuration: 1, delay: 0, animations: {
            self.universityImageViewOutlet.frame = lFrame
        })
        
        // Do any additional setup after loading the view.
    }
    
    
    

    @IBAction func showInfoAction(_ sender: UIButton) {
        universityInfoOutlet.text = textview
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
