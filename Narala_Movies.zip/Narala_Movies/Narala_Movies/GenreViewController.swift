//
//  ViewController.swift
//  Narala_Movies
//
//  Created by Narala,Jayachandra on 4/25/23.
//

import UIKit

class GenreViewController: UIViewController {

    
    
    @IBOutlet weak var genreTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

