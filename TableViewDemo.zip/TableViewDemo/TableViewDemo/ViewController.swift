//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Narala,Jayachandra on 4/13/23.
//

import UIKit

class Product{
    
    var name : String?
    var category : String?
    
    init(name : String, category : String) {
        self.name = name
        self.category = category
    }
    
} // end product class




class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // expects to return the number of products
        return products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // create a cell
        
        var mycell = TableViewOutlet.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        // populate a cell we created above
        
        mycell.textLabel?.text = products[indexPath.row].name
        
        
        // return a cell
        
        return mycell
    }
    

    
    
    
    
    @IBOutlet weak var TableViewOutlet: UITableView!
    
    // create an empty array of products
    
    var products = [Product]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let p1 = Product(name: "MacBook", category: "Laptop")
        products.append(p1)
        let p2 = Product(name: "Iphone", category: "Mobile")
        products.append(p2)
        let p3 = Product(name: "AppleBook", category: "Book")
        products.append(p3)
        let p4 = Product(name: "Airpods", category: "Accessories")
        products.append(p4)
        let p5 = Product(name: "MacDesktop", category: "Desktop")
        products.append(p5)
        
        
        TableViewOutlet.delegate = self;
        TableViewOutlet.dataSource = self;
        
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "detailSegue"{
            let destination = segue.destination as! ResultViewController
            
            // Ensure you send the product to the selected row!
            destination.product = products[(TableViewOutlet.indexPathForSelectedRow?.row)!]
        }
    }

}

