//
//  ViewController.swift
//  segueFun
//
//  Created by Narala,Jayachandra on 4/4/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

