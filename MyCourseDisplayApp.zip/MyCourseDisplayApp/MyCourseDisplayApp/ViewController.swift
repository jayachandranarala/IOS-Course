//
//  ViewController.swift
//  MyCourseDisplayApp
//
//  Created by Narala,Jayachandra on 3/16/23.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var DisplayImage: UIImageView!
    
    
    @IBOutlet weak var CRNumber: UILabel!
    
    @IBOutlet weak var CRTitle: UILabel!
    
    
    
    @IBOutlet weak var SemOffered: UILabel!
    
    
    
    @IBOutlet weak var preBtn: UIButton!
    
    
    @IBOutlet weak var nxtBtn: UIButton!
    
    let courses = [["img01","44555","Network Security","Fall2022"],["img02","44555","ios","Spring 2023"],["img03","44555","Streaming Data","Summer 2023"]]
    
    
    
    var imageNum = 0
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        // Update the details of the first course.(image,num,title,sem)
        
        
        UpdateCourse(imageNum)
        
//        DisplayImage.image = UIImage(named: courses[0][0])
//        CRNumber.text = courses[0][1]
//        CRTitle.text = courses[0][2]
//        SemOffered.text = courses[0][3]
        
        
        //Disable the previous button
        
        preBtn.isEnabled = false
        
        // Enable the next button
        nxtBtn.isEnabled = true
        
    }

    
    
    @IBAction func PreviousBtn(_ sender: UIButton) {
        
        //Decrement image number
        imageNum -= 1
        
        
        //updat the next course details
        
        UpdateCourse(imageNum)
        
        //update the previous course details
       
//        DisplayImage.image = UIImage(named: courses[imageNum][0])
//        CRNumber.text = courses[imageNum][1]
//        CRTitle.text = courses[imageNum][2]
//        SemOffered.text = courses[imageNum][3]
//
        //Enable the next button
        nxtBtn.isEnabled = true
        
        // when youi reach the starting of th array disable the previous btn
        
        if(imageNum == 0)
        {
            preBtn.isEnabled = false
        }
    }
    

    
    @IBAction func NextBtn(_ sender: UIButton) {
        
        //Increment the image number
        imageNum += 1
        
        //Update the next course details
        DisplayImage.image = UIImage(named: courses[imageNum][0])
        CRNumber.text = courses[imageNum][1]
        CRTitle.text = courses[imageNum][2]
        SemOffered.text = courses[imageNum][3]
        
        //Previous button should be enabled
        
        preBtn.isEnabled = true
        
        // When you reach end of array, next button
        
        if(imageNum == courses.count-1)
        {
            nxtBtn.isEnabled = false
        }
        
        
    }
    
    func UpdateCourse(_ imageNumber:Int){
        
        DisplayImage.image = UIImage(named: courses[imageNum][0])
        CRNumber.text = courses[imageNum][1]
        CRTitle.text = courses[imageNum][2]
        SemOffered.text = courses[imageNum][3]
    }
    
}

